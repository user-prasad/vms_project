<?php
include('dbconfig.php');
$sql = "SELECT * FROM candidate_database";
$result = $conn->query($sql);

?>

