<?php
include('dbconfig.php');
$sql = "SELECT * FROM voting_response";
$result = $conn->query($sql);

?>
